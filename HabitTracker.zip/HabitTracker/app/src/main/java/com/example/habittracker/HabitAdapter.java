package com.example.habittracker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.ViewHolder> {

    private List<Habito> habitos;
    private Context context;
    private HabitDAO habitDAO;

    public HabitAdapter(List<Habito> habitos, Context context, HabitDAO dao) {
        this.habitos = habitos;
        this.context = context;
        this.habitDAO = dao;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_habito, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Habito habito = habitos.get(position);
        holder.textViewNome.setText(habito.getNome());

        String dataHoje = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        if (dataHoje.equals(habito.getDataFeito())) {
            holder.imageStatus.setImageResource(android.R.drawable.checkbox_on_background);
        } else {
            holder.imageStatus.setImageResource(android.R.drawable.checkbox_off_background);
        }

        holder.btnFeito.setOnClickListener(v -> {
            habito.setDataFeito(dataHoje);
            habitDAO.marcarFeitoHoje(habito.getId(), dataHoje);
            notifyItemChanged(position);
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CadastroActivity.class);
            intent.putExtra("id", habito.getId());
            context.startActivity(intent);
        });

        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Excluir Hábito")
                    .setMessage("Deseja excluir este hábito?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        habitDAO.excluir(habito.getId());
                        habitos.remove(position);
                        notifyItemRemoved(position);
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return habitos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNome;
        Button btnFeito;
        ImageView imageStatus;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewNome = itemView.findViewById(R.id.textViewNome);
            btnFeito = itemView.findViewById(R.id.btnFeito);
            imageStatus = itemView.findViewById(R.id.imageStatus);
        }
    }
}
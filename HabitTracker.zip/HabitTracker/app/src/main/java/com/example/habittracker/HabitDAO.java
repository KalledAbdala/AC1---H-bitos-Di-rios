package com.example.habittracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class HabitDAO {

    private DatabaseHelper dbHelper;

    public HabitDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public List<Habito> buscarTodos() {
        List<Habito> lista = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_HABITOS,
                null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            String nome = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOME));
            String descricao = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DESCRICAO));
            String dataFeito = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATA_FEITO));
            lista.add(new Habito(id, nome, descricao, dataFeito));
        }

        cursor.close();
        db.close();
        return lista;
    }

    public void inserir(String nome, String descricao) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(DatabaseHelper.COLUMN_NOME, nome);
        valores.put(DatabaseHelper.COLUMN_DESCRICAO, descricao);
        db.insert(DatabaseHelper.TABLE_HABITOS, null, valores);
        db.close();
    }

    public void atualizar(int id, String nome, String descricao) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(DatabaseHelper.COLUMN_NOME, nome);
        valores.put(DatabaseHelper.COLUMN_DESCRICAO, descricao);
        db.update(DatabaseHelper.TABLE_HABITOS, valores, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void excluir(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_HABITOS, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void marcarFeitoHoje(int id, String data) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put(DatabaseHelper.COLUMN_DATA_FEITO, data);
        db.update(DatabaseHelper.TABLE_HABITOS, valores, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public Habito buscarPorId(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_HABITOS, null, "id=?", new String[]{String.valueOf(id)},
                null, null, null);
        if (cursor.moveToFirst()) {
            String nome = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOME));
            String descricao = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DESCRICAO));
            String data = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATA_FEITO));
            cursor.close();
            db.close();
            return new Habito(id, nome, descricao, data);
        }
        cursor.close();
        db.close();
        return null;
    }
}